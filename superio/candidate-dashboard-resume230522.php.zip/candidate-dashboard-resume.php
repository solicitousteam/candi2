<?php include 'candidate-auth-session.php';
// include 'candidate-header.html';
// include 'sidebar.php';
?>
<!DOCTYPE html>
<html lang="en">



<head>
  <meta charset="utf-8">
  <title>Candi.ai</title>

  <!-- Stylesheets -->
  <link href="css/bootstrap.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <link href="css/responsive.css" rel="stylesheet">
  <link href="css/modal.css" rel="stylesheet">

  <link rel="shortcut icon" href="images/Candi-AI-06.png" type="image/x-icon">
  <link rel="icon" href="images/Candi-AI-06.png" type="image/x-icon">
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"> -->

<!-- <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>  -->
<!-- Responsive -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
  <!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

  <div class="page-wrapper dashboard">

    <!-- Preloader -->
    <!-- <div class="preloader"></div> -->

    <!-- Header Span -->
    <span class="header-span"></span>

    <!-- Main Header-->
    <?php
  include 'sidebar.php';
?>
   <!--<header class="main-header header-shaddow">-->
   <!--     <div class="container-fluid">-->
          <!-- Main box -->
          <div class="main-box">
            <!--Nav Outer -->
            <!--<div class="nav-outer">-->
            <!--  <div class="logo-box">  -->
            <!--    <div class="logo">-->
            <!--                  <a href="index.html"-->
            <!--  ><img src="images/Candi-AI-07.png" style="height: 35px; width: 141px;" alt="" title=""></a>-->
            <!--    </div>-->
            <!--  </div>-->
<!-- Only for Mobile View -->
                  <li class="mm-add-listing">
                    <a href="add-listing.html" class="theme-btn btn-style-one"
                      >Job Post</a
                    >
                    <span>
                      <span class="contact-info">
                        <span class="phone-num"
                          ><span>Call us</span
                          ><a href="tel:1234567890">123 456 7890</a></span
                        >
                        <span class="address"
                          >329 Queensberry Street, North Melbourne VIC
                          <br />3051, Australia.</span
                        >
                        <a href="mailto:support@superio.com" class="email"
                          >support@superio.com</a
                        >
                      </span>
                      <span class="social-links">
                        <a href="#"><span class="fab fa-facebook-f"></span></a>
                        <a href="#"><span class="fab fa-twitter"></span></a>
                        <a href="#"><span class="fab fa-instagram"></span></a>
                        <a href="#"><span class="fab fa-linkedin-in"></span></a>
                      </span>
                    </span>
                  </li>
                </ul>
              </nav> 

              <!-- Main Menu End-->
            </div>

            <!--<div class="outer-box">-->
                
            <!--  <button class="menu-btn">-->
            <!--    <span class="count">1</span>-->
            <!--    <span class="icon la la-heart-o"></span>-->
            <!--  </button>-->

              <!--<button class="menu-btn">-->
              <!--    <span class="count">1</span>-->
              <!--  <span class="icon la la-bell"></span>-->
              <!--</button>-->

              <!-- Dashboard Option -->
<!--              <div class="dropdown dashboard-option">-->
<!--                <a-->
<!--                  class="dropdown-toggle"-->
<!--                  role="button"-->
<!--                  data-toggle="dropdown"-->
<!--                  aria-expanded="false"-->
<!--                >-->
<!--                  <img-->
<!--                    src="images/resource/company-6.png"-->
<!--                    alt="avatar"-->
<!--                    class="thumb"-->
<!--                  />-->
<!--                  <span class="name">My Account</span>-->
<!--                </a>-->
<!--                <ul class="dropdown-menu">-->
<!--                   <li>-->
<!--              <a href="candidate-dashboard.php"-->
<!--                ><i class="la la-home"></i>Dashboard</a-->
<!--              >-->
<!--            </li>-->
<!--            <li>-->
<!--              <a href="candidate-dashboard-profile.html"-->
<!--                ><i class="la la-user-tie"></i>My Profile</a-->
<!--              >-->
<!--            </li>-->
<!--            <li><a href="jobs_applied.php"><i class="la la-bookmark-o"></i>Jobs applied</a></li> -->
<!--<li class=""><a href="candidate-dashboard-resume.php"><i class="la la-paste"></i>My Resume</a></li>-->
<!--            <li>-->
<!--              <a href="http://r.py.solicitous.cloud/"-->
<!--                ><i class="la la-sticky-note"></i>Document Validation</a-->
<!--              >-->
<!--            </li>-->
<!--            <li class="">-->
<!--              <a href="interview-terms.php"-->
<!--                ><i class="la la-reddit"></i>Interview</a-->
<!--              >-->
<!--            </li>-->

<!--            <li>-->
<!--              <a href="job_opening.php"-->
<!--                ><i class="la la-briefcase"></i> Job Openings</a-->
<!--              >-->
<!--            </li>-->

<!--            <li>-->
<!--              <a href="candidate-dashboard-shortlisted-jobs.php"-->
<!--                ><i class="-->
<!--la la-clone"></i>Shortlisted Jobs</a-->
<!--              >-->
<!--            </li>-->

<!--            <li>-->
<!--              <a href="dashboard-change-password.php"-->
<!--                ><i class="la la-unlock-alt"></i>Change Password</a-->
<!--              >-->
<!--            </li>-->
<!--            <li>-->
<!--              <a href="change-email.html"-->
<!--                ><i class="la la-retweet"></i>Change Email</a-->
<!--              >-->
<!--            </li>-->
<!--<li>-->
<!--              <a href="delete account.html"-->
<!--                ><i class="la la-trash"></i>Delete Account</a-->
<!--              >-->
<!--            </li>-->
<!--             <li><a href="candidate-feedback.php"><i class="-->
<!--la la-thumbs-up"></i>Feedback</a></li>-->
<!--            <li>-->
<!--              <a href="candidate-logout.php"><i class="la la-sign-out"></i>Logout</a>-->
<!--            </li>-->
            
           
<!--                </ul>-->
<!--              </div>-->
<!--            </div>-->
<!--          </div>-->
<!--        </div>-->

        <!-- Mobile Header -->
        <!--<div class="mobile-header">-->
        <!--  <div class="logo">-->
        <!--               <a href="index.html"-->
        <!--      ><img src="images/Candi-AI-07.png" alt="" title=""></a>-->
        <!--  </div>-->

          <!--Nav Box-->
          <div class="nav-outer clearfix">
            <div class="outer-box">
              <!-- Login/Register -->
        <!--      <div class="login-box">-->
        <!--        <a href="login-popup.html" class="call-modal"-->
        <!--          ><span class="icon-user"></span-->
        <!--        ></a>-->
        <!--      </div>-->

        <!--      <button id="toggle-user-sidebar">-->
        <!--        <img-->
        <!--          src="images/resource/company-6.png"-->
        <!--          alt="avatar"-->
        <!--          class="thumb"-->
        <!--        />-->
        <!--      </button>-->
        <!--      <a href="#nav-mobile" class="mobile-nav-toggler navbar-trigger"-->
        <!--        ><span class="flaticon-menu-1"></span-->
        <!--      ></a>-->
        <!--    </div>-->
        <!--  </div>-->
        <!--</div>-->

        <!-- Mobile Nav -->
        <div id="nav-mobile"></div>
      </header>
    <!--End Main Header -->

    <!-- Sidebar Backdrop -->
    <div class="sidebar-backdrop"></div>

    <!-- User Sidebar -->
<!--      <div class="user-sidebar">-->
<!--        <div class="sidebar-inner">-->
<!--          <ul class="navigation">-->
<!--             <li>-->
<!--              <a href="candidate-dashboard.php"-->
<!--                ><i class="la la-home"></i>Dashboard</a-->
<!--              >-->
<!--            </li>-->
<!--            <li>-->
<!--              <a href="candidate-dashboard-profile.php"-->
<!--                ><i class="la la-user-tie"></i>My Profile</a-->
<!--              >-->
<!--            </li>-->
<!--            <li><a href="jobs_applied.php"><i class="la la-bookmark-o"></i>Jobs applied</a></li> -->
<!--<li class=""><a href="candidate-dashboard-resume.php"><i class="-->
<!--la la-paste"></i>My Resume</a></li>-->
<!--            <li>-->
<!--              <a href="http://r.py.solicitous.cloud/"-->
<!--                ><i class="la la-sticky-note"></i>Document Validation</a-->
<!--              >-->
<!--            </li>-->
<!--            <li class="">-->
<!--              <a href="interview-terms.php"-->
<!--                ><i class="la la-reddit"></i>Interview</a-->
<!--              >-->
<!--            </li>-->

<!--            <li>-->
<!--              <a href="job_opening.php"-->
<!--                ><i class="la la-briefcase"></i> Job Openings</a-->
<!--              >-->
<!--            </li>-->

<!--            <li>-->
<!--              <a href="candidate-dashboard-shortlisted-jobs.php"-->
<!--                ><i class="-->
<!--la la-clone"></i>Shortlisted Jobs</a-->
<!--              >-->
<!--            </li>-->

<!--            <li>-->
<!--              <a href="dashboard-change-password.php"-->
<!--                ><i class="la la-unlock-alt"></i>Change Password</a-->
<!--              >-->
<!--            </li>-->
<!--            <li>-->
<!--              <a href="change-email.html"-->
<!--                ><i class="la la-retweet"></i>Change Email</a-->
<!--              >-->
<!--            </li>-->
<!-- <li>-->
<!--              <a href="delete account.html"-->
<!--                ><i class="la la-trash"></i>Delete Account</a-->
<!--              >-->
<!--            </li>-->
<!--            <li><a href="candidate-feedback.php"><i class="-->
<!--la la-thumbs-up"></i>Feedback</a></li>-->
<!--            <li>-->
<!--              <a href="candidate-logout.php"><i class="la la-sign-out"></i>Logout</a>-->
<!--            </li>-->
           
<!--          </ul>-->
<!--        </div>-->
<!--      </div>-->
    <!-- End User Sidebar -->

<!-- Dashboard -->
    <section class="user-dashboard">
      <div class="dashboard-outer">
        <div class="upper-title-box">
          <h3 style="margin-top: -40px;">My Resume</h3>
          <!-- <div class="text">Ready to jump back in?</div> -->
        </div>

        <div class="row">
          <div class="col-lg-12">
            <!-- Ls widget -->
            <div class="ls-widget">
              <div class="tabs-box">
                <div class="widget-title">
                  <h4>My Profile</h4>
                </div>

                <div class="widget-content">
                  <form class="default-form">
                    <div class="row">
                      
                    
                      <!-- Search Select -->
                      <div class="form-group col-lg-6 col-md-12">
                        <label>Skills </label>
                        <select data-placeholder="Categories" class="chosen-select multiple" multiple tabindex="4">
                          <option value="Banking">Banking</option>
                          <option value="Digital&Creative">Digital & Creative</option>
                          <option value="Retail">Retail</option>
                          <option value="Human Resources">Human Resources</option>
                          <option value="Management">Management</option>
                        </select>
                      </div>
                     
                     
                     
                     
                     
                     
                     
                     <!--edu-->
                      <div class="form-group col-lg-12 col-md-12">
                        <!-- Resume / Education -->
                        <div class="resume-outer">
                          <div class="upper-title">
                            <h4>Education</h4>      
                            <!--<button  type="button"  data-toggle="modal" data-target="#exampleModal111"><i class="la la-plus-circle la-2x" ></i></span>Add Education</button>-->
                            
                            <button type="button"  data-toggle="modal" data-target="#exampleModal111" class="theme-btn btn-style-bt"><i class="las la-user-plus"></i>  Add Education</button>
                                
                                <style>
                                    .btn-style-bt{
                                        position: relative;
                                        text-align: center;
                                        white-space: nowrap;
                                        color: #ffffff;
                                        background-color: #ffa737;
                                        font-size: 15px;
                                        line-height: 2px;
                                        border-radius: 8px;
                                        font-weight: 200;
                                        padding: 13px 13px 14px 13px;
                                        }
                                </style>
                            
                            <!--<button class="add-info-btn" data-toggle="modal" data-target="#exampleModal111"><span class="icon flaticon-plus"></span> Add Education</button>-->
                          </div>
                          <!-- Resume BLock -->
                          <div class="resume-block">
                            <div class="inner">
                              <span class="name">M</span>
                              <div class="title-box">
                                <div class="info-box">
                                  <h3>Bachlors in Fine Arts</h3>
                                  <span>Modern College</span>
                                </div>
                                <div class="edit-box">
                                  <span class="year">2014</span>
                                  <div class="edit-btns">
                                    <button  type="button"  data-toggle="modal" data-target="#exampleModal111"><span class="la la-pencil"></span></button>
                                    <button><span class="la la-trash"></span></button>
                                  </div>
                                </div>
                              </div>
                              <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante<br> ipsum primis in faucibus.</div>
                            </div>
                          </div>
                          
<!------------------------------------------ ------pop up modal Edu ----------------------------------- -->

          
<div class="modal fade" id="exampleModal111" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Education</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>   
      <div class="modal-body">
        <form>
            
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Education </label>
            <input type="text" placeholder="Select Education" class="form-control" id="recipient-name">
          </div>
          
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Course</label>
            <input type="text" placeholder="Select Course" class="form-control" id="recipient-name">
          </div>
          
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Specialization</label>
            <input type="text" placeholder="Select Specialization" class="form-control" id="recipient-name">
          </div>
          
          <div class="form-group">
             <label for="recipient-name" class="col-form-label">University/Institute</label>
            <input type="text" placeholder="Select University/Institute" class="form-control" id="recipient-name">
          </div>
          
          <div class="form-group">  
           <label for="recipient-name" class="col-form-label">Course Type</label>
           <br>
                    <input type="radio" id="html" name="fav_language" value="HTML">
                    <label for="html">Full Time</label><br>
                    <input type="radio" id="css" name="fav_language" value="CSS">
                    <label for="css">Part Time</label><br>
                    <input type="radio" id="javascript" name="fav_language" value="JavaScript">
                    <label for="javascript">Correspondence/Distance learning</label>
        </div>
          
          <div class="form-group">
             <label for="recipient-name" class="col-form-label">Passing Out Year</label>
            <input type="date" placeholder="Passing Out Year" class="form-control" id="recipient-name">
          </div>
          
         
          <!--<div class="form-group">-->
          <!--   <label for="recipient-name" class="col-form-label">Grading System</label>-->
          <!--  <input type="text" placeholder="Select Grading System" class="form-control" id="recipient-name">-->
          <!--</div>-->
          <div class="form-grou">
                                            <label for="recipient-name" class="col-form-label">Grading System</label>
                                             <select class="chosen-select" >
                                                 <option value="">Scale 10 Grading System</option> 
                                              <option value="">Scale 4 Grading System</option> 
                                              <option value="">% Marks of 100 Maximum</option> 
                                              <option value="">Course Requires a Pass</option> 
                                                </select>
                                        </div>
                                        
                                         <div class="form-group">
            <label for="recipient-name" class="col-form-label">Description</label>
            <input type="text" placeholder="Type here....." class="form-control" id="recipient-name" row="4">
          </div>
          </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save</button>
      </div>
    </div>
  </div>
</div>

 <!-------------------- -------- end modal edu------------------------------------------------------------------------------>

                          <!-- Resume BLock -->
                          <div class="resume-block">
                            <div class="inner">
                              <span class="name">H</span>
                              <div class="title-box">
                                <div class="info-box">
                                  <h3>Computer Science</h3>
                                  <span>Harvard University</span>
                                </div>
                                <div class="edit-box">
                                  <span class="year">2012</span>
                                  <div class="edit-btns">
                                    <button type="button"  data-toggle="modal" data-target="#exampleModal111"><span class="la la-pencil"></span></button>
                                    <button><span class="la la-trash"></span></button>
                                  </div>
                                </div>
                              </div>
                              <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante<br> ipsum primis in faucibus.</div>
                            </div>
                          </div>
  
                        </div>
                        
                        
                        
                        
                        
                        
                        <!--work exp-->
                         <!--edu-->
                      <div class="form-group col-lg-12 col-md-12">
                        <!-- Resume / Education -->
                        <div class="resume-outer">
                          <div class="upper-title">
                            <h4>Work Experience</h4>      
                            <!--<button  type="button"  data-toggle="modal" data-target="#exampleModal111"><i class="la la-plus-circle la-2x" ></i></span>Add Education</button>-->
                            
                            <button type="button"  data-toggle="modal" data-target="#experience" class="theme-btn btn-style-bt"><i class="las la-user-plus"></i>  Add Experience</button>
                                
                                <style>
                                    .btn-style-bt{
                                        position: relative;
                                        text-align: center;
                                        white-space: nowrap;
                                        color: #ffffff;
                                        background-color: #ffa737;
                                        font-size: 15px;
                                        line-height: 2px;
                                        border-radius: 8px;
                                        font-weight: 200;
                                        padding: 13px 13px 14px 13px;
                                        }
                                </style>
                            
                            <!--<button class="add-info-btn" data-toggle="modal" data-target="#exampleModal111"><span class="icon flaticon-plus"></span> Add Education</button>-->
                          </div>
                          <!-- Resume BLock -->
                          <div class="resume-block">
                            <div class="inner">
                              <span class="name">M</span>
                              <div class="title-box">
                                <div class="info-box">
                                  <h3>Php Developer</h3>
                                  <span>Google</span>
                                </div>
                                <div class="edit-box">
                                  <span class="year">2012 - 2014</span>
                                  <div class="edit-btns">
                                    <button  type="button"  data-toggle="modal" data-target="#experience"><span class="la la-pencil"></span></button>
                                    <button><span class="la la-trash"></span></button>
                                  </div>
                                </div>
                              </div>
                              <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante<br> ipsum primis in faucibus.</div>
                            </div>
                          </div>
                          
<!------------------------------------------ ------pop up modal Edu ----------------------------------- -->

          
<div class="modal fade" id="experience" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="margin-left:500px;">
  <div class="modal-dialog modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Experience</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>   
      <div class="modal-body">
        <form>
            
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Work Title</label>
            <input type="text" placeholder="Work Title" class="form-control" id="recipient-name">
          </div>
          
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Previous Company Name</label>
            <input type="text" placeholder="Enter Previous Company Name" class="form-control" id="recipient-name">
          </div>
          
          <div class="form-group">
             <label for="recipient-name" class="col-form-label">Duration From</label>
            <input type="date" placeholder="Duration From" class="form-control" id="recipient-name">
          </div>
          
          <div class="form-group">
             <label for="recipient-name" class="col-form-label">Duration To</label>
            <input type="date" placeholder="Duration To" class="form-control" id="recipient-name">
          </div>
          
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Description</label>
            <input type="text" placeholder="Type here....." class="form-control" id="recipient-name" row="4">
          </div>
          
          
          </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save</button>
      </div>
    </div>
  </div>
</div>

 <!-------------------- -------- end modal edu------------------------------------------------------------------------------>

                          <!-- Resume BLock -->
                          <div class="resume-block">
                            <div class="inner">
                              <span class="name">H</span>
                              <div class="title-box">
                                <div class="info-box">
                                  <h3>UI Developer</h3>
                                  <span>Amazon</span>
                                </div>
                                <div class="edit-box">
                                  <span class="year">2008 - 2012</span>
                                  <div class="edit-btns">
                                    <button type="button"  data-toggle="modal" data-target="#exampleModal111"><span class="la la-pencil"></span></button>
                                    <button><span class="la la-trash"></span></button>
                                  </div>
                                </div>
                              </div>
                              <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante<br> ipsum primis in faucibus.</div>
                            </div>
                          </div>
  
                        </div>
                        
                        
                        
                        
                        
                        <!--certificate-->
                         <!--edu-->
                      <div class="form-group col-lg-12 col-md-12">
                        <!-- Resume / Education -->
                        <div class="resume-outer">
                          <div class="upper-title">
                            <h4>Certificate</h4>      
                            <!--<button  type="button"  data-toggle="modal" data-target="#exampleModal111"><i class="la la-plus-circle la-2x" ></i></span>Add Education</button>-->
                            
                            <button type="button"  data-toggle="modal" data-target="#certificate" class="theme-btn btn-style-bt"><i class="las la-user-plus"></i>  Add Certificate</button>
                                
                                <style>
                                    .btn-style-bt{
                                        position: relative;
                                        text-align: center;
                                        white-space: nowrap;
                                        color: #ffffff;
                                        background-color: #ffa737;
                                        font-size: 15px;
                                        line-height: 2px;
                                        border-radius: 8px;
                                        font-weight: 200;
                                        padding: 13px 13px 14px 13px;
                                        }
                                </style>
                            
                            <!--<button class="add-info-btn" data-toggle="modal" data-target="#exampleModal111"><span class="icon flaticon-plus"></span> Add Education</button>-->
                          </div>
                          <!-- Resume BLock -->
                          <div class="resume-block">
                            <div class="inner">
                              <span class="name">M</span>
                              <div class="title-box">
                                <div class="info-box">
                                  <h3>UI Design</h3>
                                  <span>BitDegree</span>
                                </div>
                                <div class="edit-box">
                                  <span class="year">2012 - 2014</span>
                                  <div class="edit-btns">
                                    <button  type="button"  data-toggle="modal" data-target="#certificate"><span class="la la-pencil"></span></button>
                                    <button><span class="la la-trash"></span></button>
                                  </div>
                                </div>
                              </div>
                              <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante<br> ipsum primis in faucibus.</div>
                            </div>
                          </div>
                          
<!------------------------------------------ ------pop up modal cert ----------------------------------- -->

          
<div class="modal fade" id="certificate" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="margin-left:500px;">
  <div class="modal-dialog modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"> Add Certificate</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>   
      <div class="modal-body">
        <form>
            
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Certification Name</label>
            <input type="text" placeholder="Certification Name" class="form-control" id="recipient-name">
          </div>
          
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Instituate Name</label>
            <input type="text" placeholder="Instituate Name" class="form-control" id="recipient-name">
          </div>
          
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Certification URL</label>
            <input type="text" placeholder="Certification URL" class="form-control" id="recipient-name">
          </div>
          
          <div class="form-group">
             <label for="recipient-name" class="col-form-label">Certification Validity Start From</label>
            <input type="date" placeholder="Certification Validity Start From" class="form-control" id="recipient-name">
          </div>
          
          <div class="form-group">
             <label for="recipient-name" class="col-form-label">Certification Validity Ends On</label>
            <input type="date" placeholder="Certification Validity Ends On" class="form-control" id="recipient-name">
          </div>
          
           <div class="form-group">
            <label for="recipient-name" class="col-form-label">Description</label>
            <input type="text" placeholder="Type here....." class="form-control" id="recipient-name" row="4">
          </div>
          
          
          </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save</button>
      </div>
    </div>
  </div>
</div>

 <!-------------------- -------- end modal end cert------------------------------------------------------------------------------>

                          <!-- Resume BLock -->
                          <div class="resume-block">
                            <div class="inner">
                              <span class="name">H</span>
                              <div class="title-box">
                                <div class="info-box">
                                  <h3>Graphics Design</h3>
                                  <span>Coursera</span>
                                </div>
                                <div class="edit-box">
                                  <span class="year">2008 - 2012</span>
                                  <div class="edit-btns">
                                    <button type="button"  data-toggle="modal" data-target="#exampleModal111"><span class="la la-pencil"></span></button>
                                    <button><span class="la la-trash"></span></button>
                                  </div>
                                </div>
                              </div>
                              <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante<br> ipsum primis in faucibus.</div>
                            </div>
                          </div>
  
                        </div>
                        
                        
                        
                        
                        
                        
                        
    <!-- Resume / Work & Experience -->
    <!--                    <div class="resume-outer theme-blue">-->
    <!--                      <div class="upper-title">-->
    <!--                        <h4>Work & Experience</h4>-->
    <!--                       <button type="button"  data-toggle="modal" data-target="#exampleModal888"><span class="icon flaticon-plus"></span> Add Work</button>-->
    <!--                      </div>-->
    <!--                       Resume BLock -->
    <!--                      <div class="resume-block">-->
    <!--                        <div class="inner">-->
    <!--                          <span class="name">S</span>-->
    <!--                          <div class="title-box">-->
    <!--                            <div class="info-box">-->
    <!--                              <h3>Product Designer</h3>-->
    <!--                              <span>Spotify Inc.</span>-->
    <!--                            </div>-->
    <!--                            <div class="edit-box">-->
    <!--                              <span class="year">2012 - 2014</span>-->
    <!--                              <div class="edit-btns">-->
    <!--                                <button type="button"  data-toggle="modal" data-target="#exampleModal888"><span class="la la-pencil"></span></button>-->
    <!--                                <button><span class="la la-trash"></span></button>-->
    <!--                              </div>-->
    <!--                            </div>-->
    <!--                          </div>-->
    <!--                          <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante<br> ipsum primis in faucibus.</div>-->
    <!--                        </div>-->
    <!--                      </div>-->
                          
                          
<!-- ------- modal satrt add work -------- -->

<div class="modal fade" id="exampleModal888" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"> 
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Education</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Education </label>
            <input type="text" placeholder="Product Designer" class="form-control" id="recipient-name">
            <!--<button>Add</button>-->
          </div>
          <div class="form-group">
             <label for="recipient-name" class="col-form-label">Work Experience</label>
            <input type="text" placeholder="Spotify Inc." class="form-control" id="recipient-name">
          </div>
          <div class="form-group">Certificate</label>
            <input type="text" placeholder="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus." class="form-control" id="recipient-name">
          </div>
          
         
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Edit</button>
      </div>
    </div>
  </div>

</div>

<!-- ------end modal  work --------- -->


                       <!-- Resume BLock -->
                      <!--    <div class="resume-block">-->
                      <!--      <div class="inner">-->
                      <!--        <span class="name">D</span>-->
                      <!--        <div class="title-box">-->
                      <!--          <div class="info-box">-->
                      <!--            <h3>Sr UX Engineer</h3>-->
                      <!--            <span>Dropbox Inc.</span>-->
                      <!--          </div>-->
                      <!--          <div class="edit-box">-->
                      <!--            <span class="year">2012 - 2014</span>-->
                      <!--            <div class="edit-btns">-->
                      <!--              <button type="button"  data-toggle="modal" data-target="#exampleModal888"><span class="la la-pencil"></span></button>-->
                      <!--              <button><span class="la la-trash"></span></button>-->
                      <!--            </div>-->
                      <!--          </div>-->
                      <!--        </div>-->
                      <!--        <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante<br> ipsum primis in faucibus.</div>-->
                      <!--      </div>-->
                      <!--    </div>-->

                          
                      <!--  </div>-->
                      <!--</div>-->

                      <!-- <div class="form-group col-lg-6 col-md-12">
                        <div class="uploading-outer">
                          <div class="uploadButton">
                            <input class="uploadButton-input" type="file" name="attachments[]" accept="image/*, application/pdf" id="upload" multiple />
                            <label class="uploadButton-button ripple-effect" for="upload">Add Portfolio</label>
                            <span class="uploadButton-file-name"></span>
                          </div>
                        </div>
                      </div> -->

                      <!--<div class="form-group col-lg-12 col-md-12">-->
                      <!--   Resume / Awards -->
                      <!--  <div class="resume-outer theme-yellow">-->
                      <!--    <div class="upper-title">-->
                      <!--      <h4>Certificate</h4>-->
                      <!--      <button type="button"  data-toggle="modal" data-target="#exampleModal333"><span class="icon flaticon-plus"></span> Certificate</button>-->
                      <!--    </div>-->
                      <!--     Resume BLock -->
                      <!--    <div class="resume-block">-->
                      <!--      <div class="inner">-->
                      <!--        <span class="name"></span>-->
                      <!--        <div class="title-box">-->
                      <!--          <div class="info-box">-->
                      <!--            <h3>Perfect Attendance Programs</h3>-->
                      <!--            <span></span>-->
                      <!--          </div>-->
                      <!--          <div class="edit-box">-->
                      <!--            <span class="year">2012 - 2014</span>-->
                      <!--            <div class="edit-btns">-->
                      <!--              <button type="button"  data-toggle="modal" data-target="#exampleModal333"><span class="la la-pencil"></span></button>-->
                      <!--              <button><span class="la la-trash"></span></button>-->
                      <!--            </div>-->
                      <!--          </div>-->
                      <!--        </div>-->
                      <!--        <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante<br> ipsum primis in faucibus.</div>-->
                      <!--      </div>-->
                      <!--    </div>-->
                          
<!-- ------- modal Certificate start  -------- -->

<div class="modal fade" id="exampleModal333" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Education</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Title </label>
            <input type="text" class="form-control" id="recipient-name">
            <!--<button>Add</button>-->
          </div>
          <div class="form-group">
             <label for="recipient-name" class="col-form-label">Discretion</label>
            <input type="text" class="form-control" id="recipient-name">
          </div>
          <div class="form-group">Date</label>
            <input type="date" class="form-control" id="recipient-name">
          </div>
          
         
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Add</button>
      </div>
    </div>
  </div>
</div>

<!-- ------end modal Certificate --------- -->

                          <!-- Resume BLock -->
                      <!--    <div class="resume-block">-->
                      <!--      <div class="inner">-->
                      <!--        <span class="name"></span>-->
                      <!--        <div class="title-box">-->
                      <!--          <div class="info-box">-->
                      <!--            <h3>Top Performer Recognition</h3>-->
                      <!--            <span></span>-->
                      <!--          </div>-->
                      <!--          <div class="edit-box">-->
                      <!--            <span class="year">2012 - 2014</span>-->
                      <!--            <div class="edit-btns">-->
                      <!--              <button type="button"  data-toggle="modal" data-target="#exampleModal333"><span class="la la-pencil"></span></button>-->
                      <!--              <button><span class="la la-trash" ></span></button>-->
                      <!--            </div>-->
                      <!--          </div>-->
                      <!--        </div>-->
                      <!--        <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin a ipsum tellus. Interdum et malesuada fames ac ante<br> ipsum primis in faucibus.</div>-->
                      <!--      </div>-->
                      <!--    </div>-->
                      <!--</div>-->
                      <!--</div>-->


                      <!-- Input -->
                      <div class="form-group col-lg-12 col-md-12">
                        <button class="theme-btn btn-style-one">Save</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>


        </div>
      </div>
    </section>
    <!-- End Dashboard -->

    <!-- Copyright -->
   <div class="copyright-text">
        <div class="copyright-text">	<p><a href="http://solicitousbusiness.com/" style="color:orange;">Powered with <i class="fa fa-heart" style="color:red;"></i> By</a><a href="http://solicitousbusiness.com/" style="color:orange;"> Solicitous</a></p></div>
      </div>

  </div><!-- End Page Wrapper -->


  <script src="js/jquery.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/chosen.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery-ui.min.js"></script>
  <script src="js/jquery.fancybox.js"></script>
  <script src="js/jquery.modal.min.js"></script>
  <script src="js/mmenu.polyfills.js"></script>
  <script src="js/mmenu.js"></script>
  <script src="js/appear.js"></script>
  <script src="js/ScrollMagic.min.js"></script>
  <script src="js/rellax.min.js"></script>
  <script src="js/owl.js"></script>
  <script src="js/wow.js"></script>
  <script src="js/knob.js"></script>
  <script src="js/script.js"></script>
  <!--Google Map APi Key-->
  <script src="http://maps.google.com/maps/api/js?key=AIzaSyDaaCBm4FEmgKs5cfVrh3JYue3Chj1kJMw&amp;ver=5.2.4"></script>
  <script src="js/map-script.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <!--End Google Map APi-->
</body>


<!-- Mirrored from creativelayers.net/themes/superio/candidate-dashboard-resume.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 30 Mar 2022 09:54:22 GMT -->
</html>