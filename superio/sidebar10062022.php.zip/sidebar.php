<?php
include '../connect.php';
$email=$_SESSION['email'];
$querys="Select * from candidate_register,candidate_profile where candidate_register.candidate_id=candidate_profile.candidate_id and candidate_register.candidate_email = '".$email."'"; 
$results=mysqli_query($conn,$querys);
$arrays=mysqli_fetch_assoc($results);
?>

<style>

/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
.dropdown-container {
  display: none;
  /*background-color: #262626;*/
  padding-left: 8px;
}

.fa-caret-down:before {
    content: "\f0d7";
    margin-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 8px;
}

/* Some media queries for responsiveness */
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>


 <!-- Header Span -->
 <span class="header-span"></span> 

 <!-- Main Header-->
 <header class="main-header header-shaddow">
     <div class="container-fluid">
         <!-- Main box -->
         <div class="main-box">
             <!--Nav Outer -->
             <div class="nav-outer">
                 <div class="logo-box" >
                     <div class="logo"><a href="candidate-dashboard-profile.php"><img src="images/Candi Logo Final-02.png"  style="height: 70px; width: 164px;" alt="Profile"></a></div>
                 </div>

                 <nav class="nav main-menu">
                     <ul class="navigation" id="navbar">
                        
                     </ul>     
                 </nav>
                 <!-- Main Menu End-->
             </div>


                 

             <div class="outer-box">

                 <!-- <button class="menu-btn">-->
                 <!--    <span class="count">1</span>-->
                 <!--    <span class="icon la la-heart-o"></span>-->
                 <!--</button> -->

            
                <button class="menu-btn" style="margin-right: -10px;">
                  <span class="count">1</span>
                <span class="icon la la-bell"></span>
              </button>
                

                 <!-- Dashboard Option -->
                 <div class="dropdown dashboard-option"  style="margin-right: -40px;">
                     <a role="button" aria-expanded="false" > 
                     <?php 
                     if(!empty($arrays['candidate_image'])){
                        echo "<img src='pfp/".$arrays['candidate_image']."' alt='avatar' class='thumb'>";
                     } else {    
                        echo "<img src='images/resource/company-6.png' alt='avatar' class='thumb'>";
                     } 
                     ?>
                     </a>
                     </div>
 <div class="dropdown dashboard-option">
                     <a class="dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="false" > 
                     <?php
                     if(!empty($arrays['candidate_fname'])){
                        echo "<span class='name'>".$arrays['candidate_fname']." ".$arrays['candidate_lname']."</span>";
                     }
                     else{
                        echo "<span class='name'>My Account</span>";
                     }
                         ?>
                     </a>
                     <ul class="dropdown-menu">
            <!--            <li>-->
            <!--  <a href="candidate-dashboard.php"-->
            <!--    ><i class="la la-home"></i>Dashboard</a-->
            <!--  >-->
            <!--</li>-->
           <!--<li class=""><a href="candidate-dashboard-profile.php"><i class="la la-user"></i>My Profile</a></li>-->
           
            <!--<li class=""><a href="candidate-dashboard-resume.php"><i class="la la-paste"></i>My Resume</a></li>-->
            <!--<li class=""><a href="srtresume.html"><i class="la la-paste"></i>My Resume</a></li>-->
  <!--         <li>-->
  <!--          <div class="sidenav">-->
  <!--<button class="dropdown-btn"><a><i class="la la-briefcase"></i>Jobs  <i class="fa fa-caret-down"></i></a>-->
  <!--</button>-->
  
  <!--<div class="dropdown-container" class="dropdown-menu" aria-labelledby="dropdownMenuLink">-->
  <!--  <a class="dropdown-item" href="job_opening.php"> Job Openings</a>-->
  <!--  <a class="dropdown-item" href="jobs_applied.php">Jobs applied</a>-->
    
  <!--</div>-->
  
<!--</div>-->
<!--           </li>-->
        <script>

var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
 </script>

    
           	
 
            <!--<li>-->
            <!--  <a href="http://r.py.solicitous.cloud/"-->
            <!--    ><i class="la la-sticky-note"></i>Document Validation</a-->
            <!--  >-->
            <!--</li>-->
            <!--  <li>-->
            <!--  <a href="candidate-dashboard-shortlisted-jobs.php"-->
            <!--    ><i class="la la-file-text"></i>Short Listed Jobs</a-->
            <!--  >-->
            <!--</li>-->
            <!--<li class="">-->
            <!--  <a href="interview-terms.php"-->
            <!--    ><i class="la la-reddit"></i>Candi Interview</a-->
            <!--  >-->
            <!--</li>-->

            

          

            <!-- <li><a href="dashboard-change-password.php"><i class="la la-unlock-alt"></i>Change Password</a></li>-->
            <!--<li><a href="change-email.php"><i class="la la-retweet"></i>Change Email</a></li>-->
            <!--<li><a href="accpass.php"><i class="la la-trash"></i>Delete Account</a></li>-->
             <!--<li><a href="candidate-feedback.php"><i class="la la-thumbs-up"></i>Feedback</a></li>-->
             <!--<li><a href=""><i class="la la-rupee"></i>Refer & Earn</a></li>-->
            <!--<li>-->
            <!--  <a href="candidate-logout.php"><i class="la la-sign-out"></i>Logout</a>-->
            <!--</li>-->
  <!--           <li class="dropdown">-->
             
  <!--            <a href="" class="dropdown-toggle"-->
  <!--              id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="la la-cog"></i> Account Setting-->
  <!--            </a>-->
  <!--            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">-->
   
    
  <!--  <a class="dropdown-item" href="dashboard-change-password.php">Change Password</a>-->
  <!--  <a class="dropdown-item" href="change-email.php">Change Email</a>-->
  <!--  <a class="dropdown-item" href="#">Update Profile</a>-->
  <!--  <a class="dropdown-item" href="candidate-logout.php">Logout</a>-->
  <!--  <a class="dropdown-item" href="accpass.php">Delete Profile</a>-->
  <!--</div>-->
  <!--          </li>-->
  
  <!--<li>-->
   <li>
              <a href="candidate-dashboard-profile.php"><i class="la la-user-tie"></i>My Profile</a>
            </li>
  
           <li>
              <a href="dashboard-change-password.php"><i class="la la-check-circle"></i>Change Password</a>
            </li>
            <li>
              <a href="change-email.php"><i class="la la-envelope-o"></i>Change Email</a>
            </li>
            <li>
              <a href="candidate-logout.php"><i class="la la-sign-out"></i>Logout</a>
            </li>
            <!--<div class="sidenav">-->
  <!--<button class="dropdown-btn"><a><i class="la la-cog"></i>Account Setting  <i class="fa fa-caret-down"></i></a>-->
  <!--<a href="candidate-dashboard-applied-job.html" class="dropdown-toggle"-->
  <!--              id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="la la-cog"></i> Account Setting-->
  <!--            </a>-->
  <!--</button>-->
  
  <!--<div class="dropdown-container" class="dropdown-menu" aria-labelledby="dropdownMenuLink">-->
  <!--   <a class="dropdown-item" href="dashboard-change-password.php">Change Password</a>-->
  <!--  <a class="dropdown-item" href="change-email.php">Change Email</a>-->
    <!--<a class="dropdown-item" href="#">Update Profile</a>-->
  <!--  <a class="dropdown-item" href="candidate-logout.php">Logout</a>-->
  <!--  <a class="dropdown-item" href="accpass.php">Delete Profile</a>-->
  <!--</div>-->
  
<!--</div>-->
           </li>
           <script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script>

            
                     </ul>
                 </div>
             </div>
         </div>
     </div>

     <!-- Mobile Header -->
     <div class="mobile-header">
         <div class="logo"><a href="candidate-dashboard-profile.php"><img src="images/Candi Logo Final-02.png" alt="" title=""></a></div>

         <!--Nav Box-->
         <div class="nav-outer clearfix">

             <div class="outer-box">
               <button class="menu-btn">
                  <span class="count">1</span>
                <span class="icon la la-bell"></span>
              </button>
                <div class="dropdown dashboard-option">
                     <a class="dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="false" > 
                     <?php 
                     if(!empty($arrays['candidate_image'])){
                        echo "<img src='pfp/".$arrays['candidate_image']."' alt='avatar' class='thumb'>";
                     } else {    
                        echo "<img src='images/resource/company-6.png' alt='avatar' class='thumb'>";
                     } 

                     if(!empty($arrays['candidate_fname'])){
                        echo "<span class='name'>".$arrays['candidate_fname']." ".$arrays['candidate_lname']."</span>";
                     }
                     else{
                        echo "<span class='name'>My Account</span>";
                     }
                         ?>
                     </a>
                     <ul class="dropdown-menu">
                        <li>
              <a href="candidate-dashboard.php"
                ><i class="la la-home"></i>Dashboard</a
              >
            </li>
           <li class=""><a href="candidate-dashboard-profile.php"><i class="la la-user"></i>My Profile</a></li>
           
            <li class=""><a href="candidate-dashboard-resume.php"><i class="la la-paste"></i>My Resume</a></li>
            <li>
            <div class="sidenav">
  <button class="dropdown-btn"><a><i class="la la-briefcase"></i>Jobs  <i class="fa fa-caret-down"></i></a>
  </button>
  
  <div class="dropdown-container" class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="job_opening.php"> Job Openings</a>
    <a class="dropdown-item" href="jobs_applied.php">Jobs applied</a>
    
  </div>
  
</div>
           </li>
           <script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 1; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script>

              
             </div>
         </div>
         
     </div>
     

     <!-- Mobile Nav -->
     <div id="nav-mobile"></div>
 </header>
 <!--End Main Header -->

  <!-- Sidebar Backdrop -->
  <div class="sidebar-backdrop"></div>

<!-- User Sidebar -->
<div class="user-sidebar">

    <div class="sidebar-inner">
        <ul class="navigation">
             <li>
              <a href="candidate-dashboard.php"
                ><i class="la la-home"></i>Dashboard</a
              >
            </li>
           
           <li class=""><a href="candidate-dashboard-profile.php"><i class="la la-user"></i>My Profile</a></li>
            <li class=""><a href="candidate-dashboard-resume.php"><i class="la la-paste"></i>My Resume</a></li>
          
            <li>
            <div class="sidenav">
  <button class="dropdown-btn"><a><i class="la la-briefcase"></i>Jobs  <i class="fa fa-caret-down"></i></a>
  </button>
  
  <div class="dropdown-container" class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="job_opening.php"> Job Openings</a>
    <a class="dropdown-item" href="jobs_applied.php">Jobs applied</a>
    
  </div>
  
</div>
           </li>
           <script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 1; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script>

    
               
            
            
           
				
            <!--<li>-->
            <!--  <a href="job_opening.php"-->
            <!--    ><i class="la la-briefcase"></i> Job Openings</a-->
            <!--  >-->
            <!--</li>-->
            <!--<li><a href="jobs_applied.php"><i class="la la-bookmark-o"></i>Jobs applied</a></li> -->

            <li>
              <a href="http://r.py.solicitous.cloud/"
                ><i class="la la-sticky-note"></i>Document Validation</a
              >
            </li>
              <li>
              <a href="candidate-dashboard-shortlisted-jobs.php"
                ><i class="la la-file-text"></i>Short Listed Jobs</a
              >
            </li>
            <li class="">
              <a href="interview-terms.php"
                ><i class="la la-reddit"></i>Candi Interview</a
              >
            </li>

            

          

            <!-- <li><a href="dashboard-change-password.php"><i class="la la-unlock-alt"></i>Change Password</a></li>-->
            <!--<li><a href="change-email.php"><i class="la la-retweet"></i>Change Email</a></li>-->
            <!--<li><a href="accpass.php"><i class="la la-trash"></i>Delete Account</a></li>-->
             <li><a href="candidate-feedback.php"><i class="la la-thumbs-up"></i>Feedback</a></li>
             <li><a href=""><i class="la la-rupee"></i>Refer & Earn</a></li>
            <!--<li>-->
            <!--  <a href="candidate-logout.php"><i class="la la-sign-out"></i>Logout</a>-->
            <!--</li>-->
  <!--           <li class="dropdown">-->
  <!--            <a href="" class="dropdown-toggle"-->
  <!--              id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="la la-cog"></i> Account Setting-->
  <!--            </a>-->
  <!--            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">-->
   
  <!--  <a class="dropdown-item" href="dashboard-change-password.php">Change Password</a>-->
  <!--  <a class="dropdown-item" href="change-email.php">Change Email</a>-->
  <!--  <a class="dropdown-item" href="#">Update Profile</a>-->
  <!--  <a class="dropdown-item" href="candidate-logout.php">Logout</a>-->
  <!--  <a class="dropdown-item" href="accpass.php">Delete Profile</a>-->
  <!--</div>-->
  <!--          </li>-->
  
  <li>
            <div class="sidenav">
  <button class="dropdown-btn"><a><i class="la la-cog"></i>Account Setting  <i class="fa fa-caret-down"></i></a>
  </button>
  
  <div class="dropdown-container" class="dropdown-menu" aria-labelledby="dropdownMenuLink">
     <a class="dropdown-item" href="dashboard-change-password.php">Change Password</a>
    <a class="dropdown-item" href="change-email.php">Change Email</a>
    <!--<a class="dropdown-item" href="#">Update Profile</a>-->
    <a class="dropdown-item" href="candidate-logout.php">Logout</a>
    <a class="dropdown-item" href="accpass.php">Delete Profile</a>
  </div>
  
</div>
           </li>
           <script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 2; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script>

            
        </ul>

      
    </div>
</div>

<!-- End User Sidebar -->









